﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTDLGT_De8_BinarySearchTree
{
    public class Customer
    {
        public string CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime Birthday { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }

        public string AccountID { get; set; }
        public Customer(string iD, string customerName, string phoneNumber, DateTime birthday, string address, string email, string accountID)
        {
            CustomerID = iD;
            CustomerName = customerName;
            PhoneNumber = phoneNumber;
            Birthday = birthday;
            Address = address;
            Email = email;
            AccountID = accountID;
        }
        public static List<Customer> GetCustomers()
        {
            List<Customer> customer = new List<Customer>();
            customer.Add(new Customer("3384", "Nguyễn Duy Tân", "0776397989", new DateTime(2005, 04, 15), "310 Nguyễn Đình Chiểu, Quận 3, TP.Hồ Chí Minh", "natyud@gmail.com", "DT1234"));
            customer.Add(new Customer("5420", "Thái Hoài An", "0142205682", new DateTime(2005, 04, 03), "273 Nguyễn Trãi, Quận 5, TP.Hồ Chí Minh", "aht@gmail.com", "DT1232"));
            customer.Add(new Customer("5707", "Lê Vy", "0427384025", new DateTime(2005, 08, 22), "743 Nguyễn Văn Linh, Quận 8, TP.Hồ Chí Minh", "zyle@gmail.com", "DT1235"));
            customer.Add(new Customer("4558", "Nguyễn Thị Thùy Dương", "0382633892", new DateTime(2005, 05, 25), "223 Điện Biên Phủ, Quận 3, TP.Hồ Chí Minh", "duongthuy@gmail.com", "DT1233"));
            return customer;
        }

        public static string FindName(string accountID, List<Customer> customers)
        {
            foreach (Customer customer in customers)
            {
                if (customer.AccountID == accountID)
                {
                    return customer.CustomerName;
                }
            }
            return null;
        }

        public static Customer FindInfo(string accountID, List<Customer> customers)
        {
            foreach (Customer customer in customers)
            {
                if (customer.AccountID == accountID)
                {
                    return customer;
                }
            }
            return null;
        }

        public static void Update(string id, string name, DateTime birth, string phone, string address, string email, List<Customer> list)
        {
            Customer customer = FindInfo(id, list);
            customer.CustomerName = name;
            customer.Address = address;
            customer.Email = email;
            customer.Birthday = birth;
            customer.PhoneNumber = phone;
            list.Remove(customer);
            list.Add(customer);
        }
    }
}
