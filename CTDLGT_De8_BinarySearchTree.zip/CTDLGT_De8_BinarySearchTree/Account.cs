﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTDLGT_De8_BinarySearchTree
{
    public class Account
    {
        public string AccountID {  get; set; }
        public string AccountName { get; set; }
        public int Balance { get; set; } = 0;
        public int TransactionNum { get; set; } = 0;
        public DateTime AccountDate { get; set; }

        public Account(string accountID, List<Customer> customers, List<Transaction> transactions)
        {
            AccountID = accountID;
            AccountName = Customer.FindName(accountID, customers);
            List<(DateTime, string, int)> info = Transaction.FindTransInfo(accountID, transactions);
            AccountDate = info[0].Item1;
            for (int i = 0; i < info.Count; i++)
            {
                TransactionNum = TransactionNum + 1;
                if (AccountDate.CompareTo(info[i].Item1) > 0)
                {
                    AccountDate = info[i].Item1;
                }
                if (info[i].Item2.Equals(" Nạp tiền"))
                {
                    Balance = Balance + info[i].Item3;
                }
                else
                {
                    Balance = Balance - info[i].Item3;
                }
            }
        }
        public static List<Account> GetAccounts()
        {
            List<Account> accounts = new List<Account>();
            accounts.Add(new Account("DT1234", Customer.GetCustomers(), Transaction.GetTransaction()));
            accounts.Add(new Account("DT1233", Customer.GetCustomers(), Transaction.GetTransaction()));
            accounts.Add(new Account("DT1232", Customer.GetCustomers(), Transaction.GetTransaction()));
            accounts.Add(new Account("DT1235", Customer.GetCustomers(), Transaction.GetTransaction()));
            return accounts;
        }

        public void Refresh(List<Transaction> transactions)
        {
            this.TransactionNum = 0;
            this.Balance = 0;
            List<(DateTime, string, int)> info = Transaction.FindTransInfo(this.AccountID, transactions);
            for (int i = 0; i < info.Count; i++)
            {
                this.TransactionNum = this.TransactionNum + 1;
                if (info[i].Item2.Equals(" Nạp tiền"))
                {
                    this.Balance = this.Balance + info[i].Item3;
                }
                else
                {
                    this.Balance = this.Balance - info[i].Item3;
                }
            }
        }

        public void Refresh(string accountid, List<Customer> customers)
        {
            this.AccountName = Customer.FindName(accountid, customers);
        }
    }
}
