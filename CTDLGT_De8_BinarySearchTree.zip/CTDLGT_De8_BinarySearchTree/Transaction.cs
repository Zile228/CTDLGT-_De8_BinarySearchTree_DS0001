﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace CTDLGT_De8_BinarySearchTree
{
    public class Transaction
    {
        public string TransactionID { get; set; }
        public string Account {  get; set; }
        public DateTime TransactionDate { get; set; }
        public string TransactionType { get; set; }
        public int Amount { get; set; }

        public Transaction(string transactionID, string account, DateTime transactionDate, string transactionType, int amount)
        {
            TransactionID = transactionID;
            Account = account;
            TransactionDate = transactionDate;
            TransactionType = transactionType;
            Amount = amount;
        }


        public static List<Transaction> GetTransaction()
        {
            List<Transaction> transactions = new List<Transaction>();
            transactions.Add(new Transaction("TS00001", "DT1234", new DateTime(2023, 10, 22, 08, 19, 22), " Nạp tiền", 200000));
            transactions.Add(new Transaction("TS00002", "DT1232", new DateTime(2023, 10, 25, 12, 15, 10), " Nạp tiền", 500000));
            transactions.Add(new Transaction("TS00003", "DT1233", new DateTime(2023, 11, 22, 19, 26, 11), " Nạp tiền", 50000));
            transactions.Add(new Transaction("TS00004", "DT1233", new DateTime(2023, 11, 29, 09, 47, 5), " Rút tiền", 10000));
            transactions.Add(new Transaction("TS00005", "DT1234", new DateTime(2023, 12, 3, 08, 19, 22), " Rút tiền", 50000));
            transactions.Add(new Transaction("TS00006", "DT1232", new DateTime(2023, 12, 5, 12, 15, 10), " Rút tiền", 100000));
            transactions.Add(new Transaction("TS00007", "DT1233", new DateTime(2023, 12, 9, 09, 47, 5), " Nạp tiền", 200000));
            transactions.Add(new Transaction("TS00008", "DT1235", new DateTime(2024, 1, 1, 10, 27, 31), " Nạp tiền", 200000));
            return transactions;
        }

        public static List<(DateTime, string, int)> FindTransInfo(string AccountID, List<Transaction> infolist)
        {
            List<Transaction> info = GetTransactionsInfo(AccountID, infolist);
            var result = new List<(DateTime, string, int)>();
            foreach (var i in info)
            {
                result.Add((i.TransactionDate, i.TransactionType, i.Amount));
            }
            return result;
        }

        public static List<Transaction> GetTransactionsInfo(string AccountID, List<Transaction> info)
        {
            List<Transaction> transactions = new List<Transaction>();
            foreach(Transaction transaction in info)
            {
                if(transaction.Account.Equals(AccountID))
                {
                    transactions.Add(transaction);
                }
            }
            return transactions;
        }         
    }
}
