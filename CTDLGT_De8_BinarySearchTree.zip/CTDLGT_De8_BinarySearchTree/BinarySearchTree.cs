﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTDLGT_De8_BinarySearchTree
{
    public class Node
    {
        public Account Data { get; set; }
        public Node Left { get; set; }
        public Node Right { get; set; }

        public Node(Account account)
        {
            Data = account;
            Left = Right = null;
        }
    }
    public class BinarySearchTree
    {
        public Node root;

        public BinarySearchTree()
        {
            root = null;
        }

        // Phương thức chèn tài khoản vào cây
        public void Insert(Account account)
        {
            Node newNode = new Node(account);

            if (root == null)
            {
                root = newNode;  // Nếu cây trống, đặt nút mới làm gốc
            }
            else
            {
                Node current = root;
                Node parent;

                // Lặp để tìm vị trí chèn
                while (true)
                {
                    parent = current;

                    // Nếu tài khoản mới có ngày tạo nhỏ hơn ngày tạo của nút hiện tại
                    if (account.AccountDate.CompareTo(current.Data.AccountDate) <= 0)
                    {
                        current = current.Left;

                        // Nếu không có nút con bên trái, chèn vào đó
                        if (current == null)
                        {
                            parent.Left = newNode;
                            break;
                        }
                    }
                    else if (account.AccountDate.CompareTo(current.Data.AccountDate) > 0)
                    {
                        current = current.Right;

                        // Nếu không có nút con bên phải, chèn vào đó
                        if (current == null)
                        {
                            parent.Right = newNode;
                            break;
                        }
                    }
                }
            }
        }
        // Phương thức xóa nút theo AccountID
        public void DeleteByAccountID(string accountID)
        {
            this.root = Remove(this.root, accountID);
        }

        private Node Remove(Node parent, string accountID)
        {
            if (FindByAccountID(accountID) is null) { return null; }
            else
            {
                DateTime accountDate = FindByAccountID(accountID).AccountDate;
                if (parent == null) return parent;
                if (accountDate.CompareTo(parent.Data.AccountDate) < 0) parent.Left = Remove(parent.Left, accountID);
                else if (accountDate.CompareTo(parent.Data.AccountDate) > 0) parent.Right = Remove(parent.Right, accountID);
                else //Xóa nút hiện tại
                {
                    // Nếu nút hiện tại có 1 nút con hoặc là lá
                    if (parent.Left == null) return parent.Right;
                    else if (parent.Right == null) return parent.Left;

                    //Nếu nút hiện tại có hai con: Lấy nút nhỏ hơn (bên trái)
                    parent.Data = MinValueOfNode(parent.Right);
                    parent.Right = Remove(parent.Right, parent.Right.Data.AccountID);
                }
                return parent;
            }
        }

        public Account FindMin()
        {
            return MinValueOfNode(this.root);
        }

        private Account MinValueOfNode(Node node)
        {
            Account min = node.Data;
            while (node.Left != null)
            {
                min = node.Left.Data;
                node = node.Left;
            }
            return min;
        }

        public Account FindMax()
        {
            return MaxValueOfNode(this.root);
        }

        private Account MaxValueOfNode(Node node)
        {
            Account max = node.Data;
            while (node.Right != null)
            {
                max = node.Right.Data;
                node = node.Right;
            }
            return max;
        }

        // Phương thức duyệt cây theo thứ tự InOrder

        public void InOrder(Node theRoot)
        {
            if (theRoot != null)
            {
                InOrder(theRoot.Left);  // Duyệt cây con bên trái
                Console.WriteLine($"Account ID: {theRoot.Data.AccountID}, Account Name: {theRoot.Data.AccountName}, Balance: {theRoot.Data.Balance}, Date: {theRoot.Data.AccountDate.ToShortDateString()}");  // In thông tin
                InOrder(theRoot.Right); // Duyệt cây con bên phải
            }
        }

        public void PreOrder(Node theRoot, List<Account> preorder)
        {
            if (!(theRoot == null))
            {
                preorder.Add(theRoot.Data);
                PreOrder(theRoot.Left, preorder);
                PreOrder(theRoot.Right, preorder);
            }
        }

        public List<Account> GetPreOrder()
        {
            List<Account> preorder = new List<Account>();
            PreOrder(this.root, preorder);
            return preorder;
        }
        public void PostOrder(Node theRoot)
        {
            if (!(theRoot == null))
            {
                PostOrder(theRoot.Left);
                PostOrder(theRoot.Right);
                Console.WriteLine($"Account ID: {theRoot.Data.AccountID}, Account Name: {theRoot.Data.AccountName}, Balance: {theRoot.Data.Balance}, Date: {theRoot.Data.AccountDate.ToShortDateString()}");  // In thông tin
            }
        }

        // Phương thức tìm kiếm theo Tên
        public List<Account> FindByName(string name)
        {
            List<Account> result = new List<Account>();
            FindByName(root, name, result);
            return result;
        }

        private void FindByName(Node node, string name, List<Account> result)
        {
            if (node != null)
            {
                if (node.Data.AccountName.Contains(name, StringComparison.OrdinalIgnoreCase))
                {
                    result.Add(node.Data);
                }

                FindByName(node.Left, name, result);
                FindByName(node.Right, name, result);
            }
        }


        // Phương thức tìm kiếm theo Số Tài Khoản
        public Account FindByAccountID(string accountID)
        {
            Account account = null;
            FindByAccountID(root, accountID, ref account);
            return account;
        }

        // Dùng PostOrder để duyệt tìm số tài khoản
        private void FindByAccountID(Node theRoot, string accountID, ref Account account)
        {
            if (!(theRoot == null))
            {
                FindByAccountID(theRoot.Left, accountID, ref account);
                FindByAccountID(theRoot.Right, accountID, ref account);
                if (theRoot.Data.AccountID.Equals(accountID, StringComparison.OrdinalIgnoreCase))
                {
                    account = theRoot.Data;
                }
            }
        }

        // Phương thức tìm kiếm theo khoảng thời gian
        public List<Account> FindByDateRange(DateTime startDate, DateTime endDate)
        {
            List<Account> result = new List<Account>();
            FindByDateRange(root, startDate, endDate, result);
            return result;
        }

        private void FindByDateRange(Node node, DateTime startDate, DateTime endDate, List<Account> result)
        {
            if (node == null) return;

            if (node.Data.AccountDate >= startDate && node.Data.AccountDate <= endDate)
            {
                result.Add(node.Data);
            }

            FindByDateRange(node.Left, startDate, endDate, result);
            FindByDateRange(node.Right, startDate, endDate, result);
        }

        // Phương thức duyệt cây theo thứ tự tăng dần 
        public List<Account> InOrderAscending(Node theRoot)
        {
            List<Account> accounts = new List<Account>();
            InOrderAscending(theRoot, accounts);
            return accounts;
        }

        private void InOrderAscending(Node theRoot, List<Account> accounts)
        {
            if (theRoot != null)
            {
                InOrderAscending(theRoot.Left, accounts);
                accounts.Add(theRoot.Data);
                InOrderAscending(theRoot.Right, accounts);
            }
        }
        //Phương thức duyệt cây từ phải qua trái và trả về danh sách tài khoản
        public List<Account> InOrderDescending(Node theRoot)
        {
            List<Account> accounts = new List<Account>();
            InOrderDescending(theRoot, accounts);
            return accounts;
        }

        private void InOrderDescending(Node theRoot, List<Account> accounts)
        {
            if (theRoot != null)
            {
                InOrderDescending(theRoot.Right, accounts);
                accounts.Add(theRoot.Data);
                InOrderDescending(theRoot.Left, accounts);
            }
        }

        //Tìm độ sâu của cây
        private int GetTreeDepth(Node parent)
        {
            return parent == null ? 0 : Math.Max(GetTreeDepth(parent.Left), GetTreeDepth(parent.Right)) + 1;
        }
        public int GetTreeDepth()
        {
            return this.GetTreeDepth(this.root);
        }
    }
}
