﻿namespace CTDLGT_De8_BinarySearchTree
{
    partial class ChitietTK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            Exit = new Label();
            panel2 = new Panel();
            label2 = new Label();
            panel1 = new Panel();
            soTK = new Label();
            label1 = new Label();
            button1 = new Button();
            panel3 = new Panel();
            label5 = new Label();
            panel4 = new Panel();
            button2 = new Button();
            soduTK = new TextBox();
            solanGD = new TextBox();
            NgaytaoTK = new DateTimePicker();
            Birth = new DateTimePicker();
            DiaChi = new TextBox();
            Email = new TextBox();
            SDT = new TextBox();
            TenTK = new TextBox();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label3 = new Label();
            label4 = new Label();
            dataGridView2 = new DataGridView();
            TransactionID = new DataGridViewTextBoxColumn();
            Account = new DataGridViewTextBoxColumn();
            TransactionDate = new DataGridViewTextBoxColumn();
            TransactionType = new DataGridViewTextBoxColumn();
            Amount = new DataGridViewTextBoxColumn();
            label13 = new Label();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // Exit
            // 
            Exit.AutoSize = true;
            Exit.Font = new Font("Tektur ExtraBold", 13.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Exit.ForeColor = SystemColors.ButtonHighlight;
            Exit.Location = new Point(1024, 3);
            Exit.Name = "Exit";
            Exit.Size = new Size(33, 36);
            Exit.TabIndex = 0;
            Exit.Text = "X";
            Exit.Click += Exit_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(184, 226, 138);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(Exit);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1085, 43);
            panel2.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift SemiCondensed", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(12, 5);
            label2.Name = "label2";
            label2.Size = new Size(225, 34);
            label2.TabIndex = 1;
            label2.Text = "CHI TIẾT TÀI KHOẢN";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 255, 192);
            panel1.Controls.Add(soTK);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 43);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 43);
            panel1.TabIndex = 10;
            // 
            // soTK
            // 
            soTK.AutoSize = true;
            soTK.Font = new Font("Calibri", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            soTK.ForeColor = Color.Green;
            soTK.Location = new Point(151, 7);
            soTK.Name = "soTK";
            soTK.Size = new Size(107, 27);
            soTK.TabIndex = 1;
            soTK.Text = "AccountID";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Calibri", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 7);
            label1.Name = "label1";
            label1.Size = new Size(133, 27);
            label1.TabIndex = 0;
            label1.Text = "Số Tài khoản:";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(49, 102, 0);
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(871, 3);
            button1.Name = "button1";
            button1.Size = new Size(202, 35);
            button1.TabIndex = 0;
            button1.Text = "Chỉnh sửa thông tin";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(255, 255, 192);
            panel3.Controls.Add(label5);
            panel3.Location = new Point(0, 329);
            panel3.Name = "panel3";
            panel3.Size = new Size(1085, 36);
            panel3.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Calibri", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(434, 3);
            label5.Name = "label5";
            label5.Size = new Size(189, 27);
            label5.TabIndex = 4;
            label5.Text = "LỊCH SỬ GIAO DỊCH";
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ControlLightLight;
            panel4.Controls.Add(label13);
            panel4.Controls.Add(button2);
            panel4.Controls.Add(soduTK);
            panel4.Controls.Add(solanGD);
            panel4.Controls.Add(NgaytaoTK);
            panel4.Controls.Add(Birth);
            panel4.Controls.Add(DiaChi);
            panel4.Controls.Add(Email);
            panel4.Controls.Add(SDT);
            panel4.Controls.Add(TenTK);
            panel4.Controls.Add(label12);
            panel4.Controls.Add(label11);
            panel4.Controls.Add(label10);
            panel4.Controls.Add(label9);
            panel4.Controls.Add(label8);
            panel4.Controls.Add(label7);
            panel4.Controls.Add(label6);
            panel4.Controls.Add(label3);
            panel4.Controls.Add(label4);
            panel4.Location = new Point(0, 85);
            panel4.Name = "panel4";
            panel4.Size = new Size(1085, 246);
            panel4.TabIndex = 12;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(224, 224, 224);
            button2.Enabled = false;
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Green;
            button2.Location = new Point(933, 198);
            button2.Name = "button2";
            button2.Size = new Size(140, 35);
            button2.TabIndex = 2;
            button2.Text = "Cập nhật";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // soduTK
            // 
            soduTK.BackColor = SystemColors.ControlLightLight;
            soduTK.Enabled = false;
            soduTK.Font = new Font("Calibri", 10F, FontStyle.Bold);
            soduTK.ForeColor = Color.Green;
            soduTK.Location = new Point(925, 150);
            soduTK.Name = "soduTK";
            soduTK.ReadOnly = true;
            soduTK.Size = new Size(148, 32);
            soduTK.TabIndex = 18;
            // 
            // solanGD
            // 
            solanGD.BackColor = SystemColors.ControlLightLight;
            solanGD.Enabled = false;
            solanGD.Font = new Font("Calibri", 10F, FontStyle.Bold);
            solanGD.ForeColor = Color.Green;
            solanGD.Location = new Point(925, 87);
            solanGD.Name = "solanGD";
            solanGD.ReadOnly = true;
            solanGD.Size = new Size(148, 32);
            solanGD.TabIndex = 17;
            // 
            // NgaytaoTK
            // 
            NgaytaoTK.Enabled = false;
            NgaytaoTK.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            NgaytaoTK.Format = DateTimePickerFormat.Short;
            NgaytaoTK.Location = new Point(930, 35);
            NgaytaoTK.Name = "NgaytaoTK";
            NgaytaoTK.Size = new Size(143, 31);
            NgaytaoTK.TabIndex = 16;
            // 
            // Birth
            // 
            Birth.Enabled = false;
            Birth.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Birth.Format = DateTimePickerFormat.Short;
            Birth.Location = new Point(541, 45);
            Birth.Name = "Birth";
            Birth.Size = new Size(171, 31);
            Birth.TabIndex = 15;
            // 
            // DiaChi
            // 
            DiaChi.BackColor = SystemColors.ControlLightLight;
            DiaChi.Enabled = false;
            DiaChi.Font = new Font("Calibri", 10F, FontStyle.Bold);
            DiaChi.ForeColor = Color.Green;
            DiaChi.Location = new Point(96, 135);
            DiaChi.Multiline = true;
            DiaChi.Name = "DiaChi";
            DiaChi.Size = new Size(274, 74);
            DiaChi.TabIndex = 14;
            // 
            // Email
            // 
            Email.BackColor = SystemColors.ControlLightLight;
            Email.Enabled = false;
            Email.Font = new Font("Calibri", 10F, FontStyle.Bold);
            Email.ForeColor = Color.Green;
            Email.Location = new Point(541, 144);
            Email.Name = "Email";
            Email.Size = new Size(176, 32);
            Email.TabIndex = 13;
            // 
            // SDT
            // 
            SDT.BackColor = SystemColors.ControlLightLight;
            SDT.Enabled = false;
            SDT.Font = new Font("Calibri", 10F, FontStyle.Bold);
            SDT.ForeColor = Color.Green;
            SDT.Location = new Point(541, 89);
            SDT.Name = "SDT";
            SDT.Size = new Size(176, 32);
            SDT.TabIndex = 12;
            // 
            // TenTK
            // 
            TenTK.BackColor = SystemColors.ControlLightLight;
            TenTK.Enabled = false;
            TenTK.Font = new Font("Calibri", 10F, FontStyle.Bold);
            TenTK.ForeColor = Color.Green;
            TenTK.Location = new Point(149, 55);
            TenTK.Name = "TenTK";
            TenTK.Size = new Size(221, 32);
            TenTK.TabIndex = 11;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Calibri", 10F, FontStyle.Bold);
            label12.Location = new Point(772, 91);
            label12.Name = "label12";
            label12.Size = new Size(147, 24);
            label12.TabIndex = 10;
            label12.Text = "Số lần giao dịch:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Calibri", 10F, FontStyle.Bold);
            label11.Location = new Point(768, 152);
            label11.Name = "label11";
            label11.Size = new Size(151, 24);
            label11.TabIndex = 9;
            label11.Text = "Số dư Tài khoản:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Calibri", 10F, FontStyle.Bold);
            label10.Location = new Point(748, 39);
            label10.Name = "label10";
            label10.Size = new Size(176, 24);
            label10.TabIndex = 8;
            label10.Text = "Ngày tạo Tài khoản:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Calibri", 10F, FontStyle.Bold);
            label9.Location = new Point(402, 146);
            label9.Name = "label9";
            label9.Size = new Size(62, 24);
            label9.TabIndex = 7;
            label9.Text = "Email:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Calibri", 10F, FontStyle.Bold);
            label8.Location = new Point(402, 92);
            label8.Name = "label8";
            label8.Size = new Size(127, 24);
            label8.TabIndex = 6;
            label8.Text = "Số điện thoại:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Calibri", 10F, FontStyle.Bold);
            label7.Location = new Point(17, 159);
            label7.Name = "label7";
            label7.Size = new Size(73, 24);
            label7.TabIndex = 5;
            label7.Text = "Địa chỉ:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Calibri", 10F, FontStyle.Bold);
            label6.Location = new Point(402, 47);
            label6.Name = "label6";
            label6.Size = new Size(97, 24);
            label6.TabIndex = 4;
            label6.Text = "Ngày sinh:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Calibri", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(12, 15);
            label3.Name = "label3";
            label3.Size = new Size(206, 27);
            label3.TabIndex = 3;
            label3.Text = "THÔNG TIN CÁ NHÂN";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Calibri", 10F, FontStyle.Bold);
            label4.Location = new Point(12, 57);
            label4.Name = "label4";
            label4.Size = new Size(131, 24);
            label4.TabIndex = 2;
            label4.Text = "Tên Tài khoản:";
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dataGridView2.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(242, 255, 230);
            dataGridViewCellStyle4.Font = new Font("Calibri", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = Color.FromArgb(49, 102, 0);
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(49, 102, 0);
            dataGridViewCellStyle4.SelectionForeColor = Color.FromArgb(242, 255, 230);
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Columns.AddRange(new DataGridViewColumn[] { TransactionID, Account, TransactionDate, TransactionType, Amount });
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Window;
            dataGridViewCellStyle5.Font = new Font("Calibri", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = Color.Green;
            dataGridViewCellStyle5.SelectionForeColor = Color.White;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dataGridView2.DefaultCellStyle = dataGridViewCellStyle5;
            dataGridView2.EditMode = DataGridViewEditMode.EditProgrammatically;
            dataGridView2.EnableHeadersVisualStyles = false;
            dataGridView2.Location = new Point(0, 362);
            dataGridView2.Name = "dataGridView2";
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = SystemColors.Control;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.ScrollBars = ScrollBars.Vertical;
            dataGridView2.Size = new Size(1085, 403);
            dataGridView2.TabIndex = 13;
            // 
            // TransactionID
            // 
            TransactionID.HeaderText = "Mã giao dịch";
            TransactionID.MinimumWidth = 8;
            TransactionID.Name = "TransactionID";
            TransactionID.ReadOnly = true;
            TransactionID.Width = 200;
            // 
            // Account
            // 
            Account.HeaderText = "Số Tài khoản";
            Account.MinimumWidth = 8;
            Account.Name = "Account";
            Account.ReadOnly = true;
            Account.Width = 200;
            // 
            // TransactionDate
            // 
            TransactionDate.HeaderText = "Ngày giao dịch";
            TransactionDate.MinimumWidth = 8;
            TransactionDate.Name = "TransactionDate";
            TransactionDate.ReadOnly = true;
            TransactionDate.Width = 220;
            // 
            // TransactionType
            // 
            TransactionType.HeaderText = "Loại giao dịch";
            TransactionType.MinimumWidth = 8;
            TransactionType.Name = "TransactionType";
            TransactionType.ReadOnly = true;
            TransactionType.Width = 210;
            // 
            // Amount
            // 
            Amount.HeaderText = "Số tiền";
            Amount.MinimumWidth = 8;
            Amount.Name = "Amount";
            Amount.ReadOnly = true;
            Amount.Width = 220;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Red;
            label13.Location = new Point(541, 188);
            label13.Name = "label13";
            label13.Size = new Size(45, 21);
            label13.TabIndex = 19;
            label13.Text = "Error";
            label13.Visible = false;
            // 
            // ChitietTK
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1085, 647);
            Controls.Add(dataGridView2);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ChitietTK";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ChitietTK";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label Exit;
        private Panel panel2;
        private Label label2;
        private Panel panel1;
        private Panel panel3;
        private Panel panel4;
        private DataGridView dataGridView2;
        private Button button1;
        private Label soTK;
        private Label label1;
        private Label label4;
        private Label label5;
        private Label label3;
        private Label label8;
        private Label label7;
        private Label label6;
        private TextBox DiaChi;
        private TextBox Email;
        private TextBox SDT;
        private TextBox TenTK;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private TextBox solanGD;
        private DateTimePicker NgaytaoTK;
        private DateTimePicker Birth;
        private Button button2;
        private TextBox soduTK;
        private DataGridViewTextBoxColumn TransactionID;
        private DataGridViewTextBoxColumn Account;
        private DataGridViewTextBoxColumn TransactionDate;
        private DataGridViewTextBoxColumn TransactionType;
        private DataGridViewTextBoxColumn Amount;
        private Label label13;
    }
}