﻿using System.Security.Principal;

namespace CTDLGT_De8_BinarySearchTree
{
    partial class DangKy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DangKy));
            label3 = new Label();
            textBox1 = new TextBox();
            signinButton = new Button();
            panel1 = new Panel();
            Password = new TextBox();
            Account = new TextBox();
            PasswordNo = new Label();
            AccountName = new Label();
            SignIn = new Label();
            panel2 = new Panel();
            label2 = new Label();
            label1 = new Label();
            label4 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Tahoma", 10F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(69, 447);
            label3.Name = "label3";
            label3.Size = new Size(265, 24);
            label3.TabIndex = 5;
            label3.Text = "Nhập mã xác thực cấp từ HR";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.ControlLightLight;
            textBox1.Font = new Font("Tahoma", 10F);
            textBox1.ForeColor = SystemColors.ActiveCaptionText;
            textBox1.Location = new Point(340, 444);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "  Nhập \"CTDLGT-DE8\"";
            textBox1.Size = new Size(212, 32);
            textBox1.TabIndex = 0;
            // 
            // signinButton
            // 
            signinButton.BackColor = Color.LightCyan;
            signinButton.FlatStyle = FlatStyle.Popup;
            signinButton.Font = new Font("Tahoma", 11F, FontStyle.Bold);
            signinButton.ForeColor = Color.SteelBlue;
            signinButton.Location = new Point(69, 489);
            signinButton.Name = "signinButton";
            signinButton.Size = new Size(125, 42);
            signinButton.TabIndex = 8;
            signinButton.Text = "Đăng ký";
            signinButton.UseVisualStyleBackColor = false;
            signinButton.Click += signinButton_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(Password);
            panel1.Controls.Add(Account);
            panel1.Controls.Add(PasswordNo);
            panel1.Controls.Add(AccountName);
            panel1.Controls.Add(SignIn);
            panel1.Location = new Point(27, 181);
            panel1.Name = "panel1";
            panel1.Size = new Size(683, 263);
            panel1.TabIndex = 9;
            // 
            // Password
            // 
            Password.BackColor = SystemColors.ControlLightLight;
            Password.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Password.ForeColor = SystemColors.ActiveCaptionText;
            Password.Location = new Point(41, 203);
            Password.Name = "Password";
            Password.PasswordChar = '*';
            Password.Size = new Size(483, 36);
            Password.TabIndex = 0;
            // 
            // Account
            // 
            Account.BackColor = SystemColors.ControlLightLight;
            Account.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Account.ForeColor = SystemColors.ActiveCaptionText;
            Account.Location = new Point(41, 105);
            Account.Name = "Account";
            Account.Size = new Size(483, 36);
            Account.TabIndex = 0;
            Account.WordWrap = false;
            // 
            // PasswordNo
            // 
            PasswordNo.AutoSize = true;
            PasswordNo.Font = new Font("Tahoma", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PasswordNo.ForeColor = Color.White;
            PasswordNo.Location = new Point(39, 154);
            PasswordNo.Name = "PasswordNo";
            PasswordNo.Size = new Size(147, 34);
            PasswordNo.TabIndex = 2;
            PasswordNo.Text = "Mật khẩu";
            // 
            // AccountName
            // 
            AccountName.AutoSize = true;
            AccountName.Font = new Font("Tahoma", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AccountName.ForeColor = Color.White;
            AccountName.Location = new Point(39, 57);
            AccountName.Name = "AccountName";
            AccountName.Size = new Size(207, 34);
            AccountName.TabIndex = 1;
            AccountName.Text = "Tên tài khoản";
            // 
            // SignIn
            // 
            SignIn.AutoSize = true;
            SignIn.Font = new Font("Tahoma", 18F, FontStyle.Bold);
            SignIn.ForeColor = Color.White;
            SignIn.Location = new Point(30, 0);
            SignIn.Name = "SignIn";
            SignIn.Size = new Size(187, 43);
            SignIn.TabIndex = 0;
            SignIn.Text = "ĐĂNG KÝ";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(184, 226, 138);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1085, 43);
            panel2.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift SemiCondensed", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(12, 5);
            label2.Name = "label2";
            label2.Size = new Size(111, 34);
            label2.TabIndex = 1;
            label2.Text = "ĐĂNG KÝ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tektur ExtraBold", 13.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(1030, 3);
            label1.Name = "label1";
            label1.Size = new Size(33, 36);
            label1.TabIndex = 0;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Underline);
            label4.ForeColor = SystemColors.ControlLightLight;
            label4.Location = new Point(333, 499);
            label4.Name = "label4";
            label4.Size = new Size(218, 25);
            label4.TabIndex = 11;
            label4.Text = "Bạn đã có tài khoản rồi ư?";
            label4.Click += label4_Click;
            // 
            // DangKy
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1085, 607);
            Controls.Add(label4);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(signinButton);
            Controls.Add(textBox1);
            Controls.Add(label3);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "DangKy";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DangKy";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label3;
        private TextBox textBox1;
        private Button signinButton;
        private Panel panel1;
        private TextBox Password;
        private TextBox Account;
        private Label PasswordNo;
        private Label AccountName;
        private Label SignIn;
        private Panel panel2;
        private Label label2;
        private Label label1;
        private Label label4;
    }
}