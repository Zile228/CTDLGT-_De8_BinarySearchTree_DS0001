﻿using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CTDLGT_De8_BinarySearchTree
{
    partial class QuanLyHoSo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            LogOut = new Button();
            QLGD = new Button();
            QLTK = new Button();
            Username = new Label();
            XinChao = new Label();
            avatarIcon = new PictureBox();
            hoSotk1 = new HoSoTK();
            quanLygd1 = new QuanLyGD();
            pictureBox1 = new PictureBox();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)avatarIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(184, 226, 138);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1085, 43);
            panel2.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift SemiCondensed", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(12, 5);
            label2.Name = "label2";
            label2.Size = new Size(107, 34);
            label2.TabIndex = 1;
            label2.Text = "QUẢN LÝ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tektur ExtraBold", 13.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(1030, 3);
            label1.Name = "label1";
            label1.Size = new Size(33, 36);
            label1.TabIndex = 0;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(56, 107, 17);
            panel1.Controls.Add(LogOut);
            panel1.Controls.Add(QLGD);
            panel1.Controls.Add(QLTK);
            panel1.Controls.Add(Username);
            panel1.Controls.Add(XinChao);
            panel1.Controls.Add(avatarIcon);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 43);
            panel1.Name = "panel1";
            panel1.Size = new Size(209, 564);
            panel1.TabIndex = 9;
            // 
            // LogOut
            // 
            LogOut.BackColor = Color.FromArgb(255, 128, 128);
            LogOut.FlatStyle = FlatStyle.Popup;
            LogOut.Font = new Font("Segoe UI", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LogOut.ForeColor = SystemColors.ButtonHighlight;
            LogOut.Location = new Point(96, 521);
            LogOut.Name = "LogOut";
            LogOut.Size = new Size(102, 31);
            LogOut.TabIndex = 14;
            LogOut.Text = "Đăng xuất";
            LogOut.TextAlign = ContentAlignment.TopCenter;
            LogOut.UseVisualStyleBackColor = false;
            LogOut.Click += LogOut_Click;
            // 
            // QLGD
            // 
            QLGD.BackColor = Color.FromArgb(220, 247, 208);
            QLGD.FlatStyle = FlatStyle.Popup;
            QLGD.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QLGD.Location = new Point(12, 345);
            QLGD.Name = "QLGD";
            QLGD.Size = new Size(177, 43);
            QLGD.TabIndex = 13;
            QLGD.Text = "Quản lý Giao dịch";
            QLGD.UseVisualStyleBackColor = false;
            QLGD.Click += QLGD_Click;
            // 
            // QLTK
            // 
            QLTK.BackColor = Color.FromArgb(220, 247, 208);
            QLTK.FlatStyle = FlatStyle.Popup;
            QLTK.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QLTK.Location = new Point(12, 283);
            QLTK.Name = "QLTK";
            QLTK.Size = new Size(177, 43);
            QLTK.TabIndex = 12;
            QLTK.Text = "Quản lý Tài khoản";
            QLTK.UseVisualStyleBackColor = false;
            QLTK.Click += QLTK_Click;
            // 
            // Username
            // 
            Username.AutoSize = true;
            Username.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Username.ForeColor = SystemColors.ControlLightLight;
            Username.Location = new Point(87, 42);
            Username.Name = "Username";
            Username.Size = new Size(85, 32);
            Username.TabIndex = 11;
            Username.Text = "Name";
            Username.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // XinChao
            // 
            XinChao.AutoSize = true;
            XinChao.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            XinChao.ForeColor = SystemColors.ControlLightLight;
            XinChao.Location = new Point(87, 3);
            XinChao.Name = "XinChao";
            XinChao.Size = new Size(94, 28);
            XinChao.TabIndex = 10;
            XinChao.Text = "Xin chào";
            // 
            // avatarIcon
            // 
            avatarIcon.BackgroundImage = Properties.Resources.Screenshot_2024_12_08_022613;
            avatarIcon.BackgroundImageLayout = ImageLayout.Zoom;
            avatarIcon.Location = new Point(-9, -1);
            avatarIcon.Name = "avatarIcon";
            avatarIcon.Size = new Size(90, 105);
            avatarIcon.TabIndex = 10;
            avatarIcon.TabStop = false;
            // 
            // hoSotk1
            // 
            hoSotk1.Location = new Point(215, 46);
            hoSotk1.Name = "hoSotk1";
            hoSotk1.Size = new Size(870, 561);
            hoSotk1.TabIndex = 10;
            hoSotk1.Visible = false;
            // 
            // quanLygd1
            // 
            quanLygd1.Location = new Point(209, 43);
            quanLygd1.Name = "quanLygd1";
            quanLygd1.Size = new Size(876, 562);
            quanLygd1.TabIndex = 11;
            quanLygd1.Visible = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Screenshot_2024_12_11_223254;
            pictureBox1.Location = new Point(215, 153);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(430, 440);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // QuanLyHoSo
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1085, 607);
            ControlBox = false;
            Controls.Add(pictureBox1);
            Controls.Add(quanLygd1);
            Controls.Add(hoSotk1);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "QuanLyHoSo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Quản lý hồ sơ";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)avatarIcon).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Label label2;
        private Label label1;
        private Panel panel1;
        private PictureBox avatarIcon;
        private Label XinChao;
        private Label Username;
        private HoSoTK hoSotk1;
        private Button QLTK;
        private Button QLGD;
        private Button LogOut;
        private QuanLyGD quanLygd1;
        private PictureBox pictureBox1;
    }
}